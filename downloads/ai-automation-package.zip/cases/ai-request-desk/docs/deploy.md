# Подключение и запуск

## 1. Локальный стенд

```bash
cp .env.example .env
docker compose up -d
docker compose ps
```

- n8n: <http://localhost:5678>
- Adminer: <http://localhost:8080>
- PostgreSQL с хоста: `localhost:5433`, БД `helpdesk`, пользователь `requestdesk`

При первом старте Postgres выполняет `sql/01_schema.sql` и `sql/02_seed.sql`. Если меняли схему и хотите пересоздать базу:

```bash
docker compose down -v
docker compose up -d
```

`down -v` удаляет volume с данными. Не запускайте на проде.

## 2. Импорт workflow

В n8n: **Workflows → Import from File** → `n8n/request-desk.workflow.json`.

В workflow один Telegram Trigger на два типа update:

- `message` — новая заявка;
- `callback_query` — нажатие кнопки менеджером.

Так сделано намеренно: у Telegram-бота **один webhook**. Два отдельных workflow с одним ботом будут перезаписывать webhook друг друга.

## 3. Credentials

Создайте три credentials в n8n.

### Telegram

1. Получите токен у [@BotFather](https://t.me/BotFather) командой `/newbot`.
2. В n8n: **Credentials → New → Telegram API**.
3. Вставьте токен.

Подключите этот credential к нодам:

- `Telegram Trigger`
- `03 · Ответ: нужен текст`
- `09 · Уведомить менеджера`
- `10 · Ответ клиенту`
- `13 · Ответ: неизвестная кнопка`
- `16 · Убрать «часики»`
- `17 · Обновить карточку`

### OpenRouter

1. Создайте ключ на <https://openrouter.ai/keys>.
2. В n8n: **Credentials → New → Header Auth**.
3. Name: `Authorization`
4. Value: `Bearer sk-or-...`

Подключите к ноде `05 · OpenRouter` (поле Authentication → Generic Credential Type → Header Auth).

### PostgreSQL

1. **Credentials → New → Postgres**.
2. Host: `postgres`
3. Port: `5432`
4. Database: `helpdesk`
5. User / Password: из `.env` (по умолчанию `requestdesk` / `requestdesk`).
6. SSL: off для локального стенда.

Подключите к нодам:

- `07 · Сохранить в SQL`
- `14 · Обновить статус`

## 4. Настройка workflow

Откройте ноду **«04 · Промпт и настройки»**. В начале кода:

```js
const CONFIG = {
  model: 'qwen/qwen3.7-flash',
  manager_chat_id: '',          // chat_id менеджера или группы
  manager_contact_url: 'tg://user?id=YOUR_TELEGRAM_ID', // кнопка «Связаться с менеджером»
  price_in_usd_per_1m: 0.03,
  price_out_usd_per_1m: 0.13,
  max_tokens: 400,
  temperature: 0.1,
};
```

Что важно:

- `manager_chat_id` — куда отправлять карточки. Пустая строка = демо-режим: карточка уйдёт в чат заявителя.
- `manager_contact_url` — ссылка для клиентской кнопки «Связаться с менеджером». Для личного чата: `tg://user?id=<telegram_id>`.
- `model` — можно поставить другую дешёвую модель OpenRouter.
- `reasoning: { enabled: false }` уже включён в payload: для qwen он обязателен, иначе reasoning съедает `max_tokens`.
- Цены нужны для расчёта `cost_usd`; держите их в актуальном состоянии.

### Как узнать chat_id

- Напишите боту `/start`, затем откройте:
  `https://api.telegram.org/bot<TOKEN>/getUpdates`
  и найдите `message.chat.id`.
- Для группы добавьте бота в группу и возьмите отрицательный `chat.id` (например, `-1001234567890`).
- Не публикуйте URL с токеном в скриншотах и репозитории.

## 5. Активация

1. Включите workflow (toggle **Active**).
2. Telegram зарегистрирует webhook автоматически.
3. Для Telegram Trigger нужен публичный HTTPS. Для локального запуска используйте туннель (cloudflared, ngrok) либо деплой за reverse-proxy.

Проверка, что webhook жив:

```bash
curl -s "https://api.telegram.org/bot<TOKEN>/getWebhookInfo" | python3 -m json.tool
```

В `url` должен быть адрес вашего n8n, в `last_error_message` — пусто.

## 6. Проверка сценария

1. Напишите боту:
   > Срочно! Сайт не открывается, клиенты не могут оформить заказ.
2. Ожидаемо:
   - карточка менеджеру с `support` / `critical` / SLA 15 минут;
   - ответ клиенту «Заявка #N принята»;
   - запись в Postgres.
3. Нажмите **«Взять в работу»**:
   - карточка редактируется;
   - в SQL `status=in_progress`, заполнен `assignee_name`.
4. Нажмите **«Закрыть»**:
   - `status=done`, `closed_at` заполнен.

SQL-проверка:

```bash
docker compose exec postgres psql -U requestdesk -d helpdesk -c \
  "select id, category, priority, status, assignee_name, cost_usd, created_at
   from request_desk.requests order by id desc limit 5;"
```

Просроченные SLA:

```bash
docker compose exec postgres psql -U requestdesk -d helpdesk -c \
  "select * from request_desk.v_sla_risk;"
```

## 7. Reverse-proxy и Telegram webhook

Telegram ходит на конкретный URL вида:

```text
https://<домен>/webhook/<webhookId>/webhook
```

`webhookId` — это поле `webhookId` у ноды Telegram Trigger. Если n8n стоит за Caddy/nginx с allowlist путей, новый webhook нужно явно добавить, иначе Telegram получит `404`, а в `getWebhookInfo` появится:

```json
{"last_error_message": "Wrong response from the webhook: 404 Not Found"}
```

Пример для Caddy:

```caddyfile
@telegramBotWebhook {
	path /webhook/1a6f3dd3-9eb1-4246-b4bc-1c73354949b0/webhook /webhook/e6e3b51f-1a36-4ac3-bf64-4d9e12c075bb/webhook
	method POST
}
handle @telegramBotWebhook {
	reverse_proxy n8n:5678
}
```

После правки:

```bash
caddy validate --config /etc/caddy/Caddyfile
caddy reload --config /etc/caddy/Caddyfile
```

Проверка:

```bash
curl -s "https://api.telegram.org/bot<TOKEN>/getWebhookInfo" | python3 -m json.tool
```

`last_error_message` может остаться историческим — он очистится после первого успешного update от Telegram. Отправьте боту реальное сообщение.

## 8. Частые проблемы

| Симптом | Причина / решение |
|---|---|
| Telegram Trigger не срабатывает | Workflow не активен, нет публичного HTTPS или webhook перезаписан другим ботом/сервисом |
| `401` от OpenRouter | В Header Auth забыт префикс `Bearer ` |
| `ECONNREFUSED` к Postgres | Хост должен быть `postgres` внутри compose, не `localhost` |
| AI всегда `other` + `needs_review` | Модель недоступна, неверный ключ или ответ не проходит валидацию; смотрите execution в n8n |
| Карточка не пришла | Неверный `manager_chat_id`; при этом клиентское подтверждение продолжит работать |
| Кнопки не обновляют карточку | У бота конфликт webhook, либо callback пришёл от другого сообщения |
| Два workflow на одном боте | У Telegram один webhook. Используйте один workflow или второго бота |

## 9. Публикация кейса

Перед публикацией:

- не коммитьте `.env`, токены, chat_id реальных людей;
- замените `HTTP-Referer` и `X-Title` в ноде OpenRouter на свои;
- проверьте, что в `demo/` нет реальных персональных данных;
- при публикации скриншотов уберите номера телефонов, email и имена клиентов.
