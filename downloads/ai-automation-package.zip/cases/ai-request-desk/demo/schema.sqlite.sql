CREATE TABLE IF NOT EXISTS requests (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  trace_id          TEXT NOT NULL UNIQUE,
  name              TEXT,
  username          TEXT,
  raw_text          TEXT NOT NULL,
  category          TEXT NOT NULL,
  priority          TEXT NOT NULL,
  sentiment         TEXT NOT NULL,
  summary           TEXT,
  suggested_reply   TEXT,
  confidence        REAL,
  needs_review      INTEGER NOT NULL DEFAULT 0,
  status            TEXT NOT NULL DEFAULT 'new',
  model             TEXT,
  tokens_in         INTEGER,
  tokens_out        INTEGER,
  cost_usd          REAL,
  sla_due_at        TEXT,
  created_at        TEXT NOT NULL,
  ai_raw            TEXT
);

CREATE INDEX IF NOT EXISTS idx_requests_category ON requests (category, priority);
CREATE INDEX IF NOT EXISTS idx_requests_status ON requests (status, created_at);
