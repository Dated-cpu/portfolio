#!/usr/bin/env python3
"""Локальное демо AI Request Desk.

Работает без внешних зависимостей: если OPENROUTER_API_KEY не задан,
используется офлайн-эвристика. С ключом — тот же промпт уходит в дешёвую
модель OpenRouter, а результат валидируется так же, как в n8n.

Запуск:
    python3 demo/simulate.py
    OPENROUTER_API_KEY=sk-or-... python3 demo/simulate.py
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
import sys
import urllib.error
import urllib.request
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEMO_DIR = ROOT / "demo"
DB_PATH = DEMO_DIR / "requests.db"
REQUESTS_PATH = DEMO_DIR / "requests.json"
PROMPT_PATH = ROOT / "prompts" / "classifier.md"
SCHEMA_PATH = DEMO_DIR / "schema.sqlite.sql"

MODEL = os.getenv("OPENROUTER_MODEL", "qwen/qwen3.7-flash")
PRICE_IN = 0.03
PRICE_OUT = 0.13
SLA_MINUTES = {"critical": 15, "high": 60, "normal": 240, "low": 1440}

CATEGORY_LABELS = {
    "sales": "Продажи",
    "support": "Поддержка",
    "billing": "Оплата",
    "delivery": "Доставка",
    "partnership": "Партнёрство",
    "spam": "Спам",
    "other": "Другое",
}
PRIORITY_LABELS = {
    "critical": "КРИТИЧНЫЙ",
    "high": "ВЫСОКИЙ",
    "normal": "ОБЫЧНЫЙ",
    "low": "НИЗКИЙ",
}
SENTIMENT_LABELS = {"positive": "позитивный", "neutral": "нейтральный", "negative": "негативный"}

CATEGORY_RULES = {
    "spam": {
        "база клиентов": 6, "базу клиентов": 6, "купите": 2, "подписчик": 5,
        "казино": 5, "крипт": 3, "скидка 90": 5, "пишите в личку": 4,
        "заработок": 4, "рассылка": 3, "только сегодня": 2,
    },
    "billing": {
        "оплат": 2, "списан": 5, "деньг": 3, "возврат": 4, "счет": 2,
        "счёт": 2, "инвойс": 4, "подписк": 3, "платеж": 3, "платёж": 3,
        "дважды": 4, "чек": 1,
    },
    "delivery": {
        "доставк": 5, "курьер": 4, "посылк": 4, "трек": 3, "отправлен": 2,
        "пункт выдачи": 4, "статус": 2, "заказ": 2,
    },
    "support": {
        "не работает": 6, "не открывается": 6, "ошибк": 5, "вылетает": 5,
        "баг": 4, "пароль": 4, "вход": 3, "регистрац": 4, "письмо": 2,
        "приложение": 3, "сайт": 3, "не могут": 3, "подтверждением": 2,
        "сломал": 4, "не грузит": 5,
    },
    "sales": {
        "стоимость": 4, "тариф": 4, "прайс": 4, "демо": 3, "купить": 3,
        "корпоратив": 4, "скидка": 2, "сотрудник": 1, "интеграц": 4,
        "api": 2, "условия": 2, "подключен": 2,
    },
    "partnership": {
        "партнёрств": 6, "партнерств": 6, "агентств": 4, "сотрудничеств": 5,
        "реселлер": 5, "предлагаем": 2, "коммерческое предложение": 3,
        "совместн": 2,
    },
    "other": {
        "спасибо": 5, "благодар": 4, "отзыв": 3, "всё работает": 4,
        "все работает": 4, "здравствуйте": 1,
    },
}

HIGH_KEYWORDS = [
    "списан", "дважды", "возврат", "вылетает", "не меняется", "задерж",
    "заблокир", "сломал", "не грузит", "потеряли продаж",
]
CRITICAL_KEYWORDS = ["критич", "всё лежит", "все лежит", "авария", "недоступен"]
LOW_KEYWORDS = ["спасибо", "благодар", "предлагаем партнёрство", "предлагаем партнерство"]

REPLY_TEMPLATES = {
    "billing": "Приняли обращение по оплате. Передали в финансовый отдел, вернёмся с решением.",
    "support_critical": "Приняли как критическую заявку. Инженер уже проверяет, вернёмся со статусом в течение 15 минут.",
    "support_high": "Приняли заявку в поддержку. Проверим проблему и сообщим о результате в течение часа.",
    "support": "Приняли заявку в поддержку. Проверим детали и вернёмся с ответом.",
    "delivery": "Запросили статус у службы доставки. Сообщим обновление, как только получим ответ.",
    "sales": "Передали запрос менеджеру по продажам. Подготовим расчёт и вернёмся с условиями.",
    "partnership": "Спасибо за интерес. Передали предложение в отдел развития партнёрств.",
    "spam": "",
    "other": "Спасибо за обращение! Передали его команде.",
}


def load_prompt() -> tuple[str, str]:
    text = PROMPT_PATH.read_text(encoding="utf-8")
    blocks = re.findall(r"```text\n(.*?)\n```", text, flags=re.S)
    if not blocks:
        raise RuntimeError("Не найден system prompt в prompts/classifier.md")
    system = blocks[0]
    examples = blocks[1] if len(blocks) > 1 else ""
    return system, examples


def normalize(text: str) -> str:
    return text.lower().replace("ё", "е")


def heuristic_classify(text: str) -> dict:
    low = normalize(text)
    scores = {}
    for category, rules in CATEGORY_RULES.items():
        score = 0
        for phrase, weight in rules.items():
            if normalize(phrase) in low:
                score += weight
        scores[category] = score

    category = max(scores, key=lambda c: (scores[c], c == "other"))
    if scores[category] == 0:
        category = "other"

    if category in ("spam", "partnership"):
        priority = "low"
    elif any(k in low for k in CRITICAL_KEYWORDS) or (
        "срочно" in low and any(k in low for k in ("сайт", "не работает", "не открывается", "клиент", "оплат"))
    ):
        priority = "critical"
    elif any(k in low for k in HIGH_KEYWORDS):
        priority = "high"
    elif any(k in low for k in LOW_KEYWORDS):
        priority = "low"
    else:
        priority = "normal"

    if any(k in low for k in ("спасибо", "благодар", "отлично", "супер")):
        sentiment = "positive"
    elif any(k in low for k in ("не ", "ошибк", "списан", "вылетает", "плохо", "долго", "срочно", "возврат")):
        sentiment = "negative"
    else:
        sentiment = "neutral"

    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s.strip()]
    greetings = ("здравствуйте", "добрый день", "добрый вечер", "привет", "срочно")
    candidates = [
        s for s in sentences
        if len(s) >= 25 and not normalize(s).startswith(greetings)
    ]
    first = max(candidates, key=len) if candidates else (sentences[0] if sentences else text)
    summary = first[:160].strip()
    if len(first) > 160:
        summary = summary.rstrip(" ,.;") + "…"

    if category == "support" and priority in ("critical", "high"):
        reply = REPLY_TEMPLATES["support_" + priority]
    else:
        reply = REPLY_TEMPLATES.get(category, REPLY_TEMPLATES["other"])

    top = scores[category]
    confidence = min(0.95, 0.62 + top * 0.03 + (0.03 if priority in ("high", "critical") else 0))
    needs_review = top < 3 or confidence < 0.55

    return {
        "category": category,
        "priority": priority,
        "sentiment": sentiment,
        "summary": summary,
        "suggested_reply": reply,
        "confidence": round(confidence, 2),
        "needs_review": needs_review,
        "scores": scores,
        "source": "heuristic",
    }


def ai_classify(text: str, system_prompt: str, examples: str, api_key: str) -> dict:
    user_content = f'Examples:\n{examples}\n\nMessage to classify:\n"""\n{text}\n"""\nReturn only JSON.'
    payload = {
        "model": MODEL,
        "temperature": 0.1,
        "max_tokens": 400,
        "reasoning": {"enabled": False},
        "usage": {"include": True},
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
    }
    req = urllib.request.Request(
        "https://openrouter.ai/api/v1/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://github.com/your-case/ai-request-desk",
            "X-Title": "AI Request Desk Demo",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        data = json.loads(resp.read().decode("utf-8"))

    content = data["choices"][0]["message"]["content"].strip()
    content = re.sub(r"^```(?:json)?\s*", "", content)
    content = re.sub(r"```$", "", content).strip()
    start, end = content.find("{"), content.rfind("}")
    if start != -1 and end > start:
        content = content[start : end + 1]

    parsed = json.loads(content)
    categories = ["sales", "support", "billing", "delivery", "partnership", "spam", "other"]
    priorities = ["low", "normal", "high", "critical"]
    sentiments = ["positive", "neutral", "negative"]

    usage = data.get("usage") or {}
    return {
        "category": parsed.get("category") if parsed.get("category") in categories else "other",
        "priority": parsed.get("priority") if parsed.get("priority") in priorities else "normal",
        "sentiment": parsed.get("sentiment") if parsed.get("sentiment") in sentiments else "neutral",
        "summary": str(parsed.get("summary", ""))[:160],
        "suggested_reply": str(parsed.get("suggested_reply", ""))[:240],
        "confidence": max(0.0, min(1.0, float(parsed.get("confidence", 0)))),
        "needs_review": float(parsed.get("confidence", 0)) < 0.55,
        "scores": {},
        "source": "openrouter",
        "model": data.get("model", MODEL),
        "tokens_in": int(usage.get("prompt_tokens") or 0),
        "tokens_out": int(usage.get("completion_tokens") or 0),
    }


def estimate_tokens(text: str) -> int:
    return max(1, len(text) // 4)


def init_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.execute("DROP TABLE IF EXISTS requests")
    conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
    conn.commit()
    return conn


def save_request(conn: sqlite3.Connection, item: dict, result: dict, system_prompt: str) -> dict:
    now = datetime.now(timezone.utc)
    sla_due = now + timedelta(minutes=SLA_MINUTES[result["priority"]])

    if result["source"] == "openrouter":
        tokens_in = result.get("tokens_in") or estimate_tokens(system_prompt + item["text"])
        tokens_out = result.get("tokens_out") or estimate_tokens(result["summary"] + result["suggested_reply"])
        model = result.get("model", MODEL)
    else:
        tokens_in = estimate_tokens(system_prompt + item["text"])
        tokens_out = estimate_tokens(result["summary"] + result["suggested_reply"])
        model = MODEL + " (offline estimate)"

    cost = (tokens_in / 1_000_000) * PRICE_IN + (tokens_out / 1_000_000) * PRICE_OUT
    trace_id = f"demo_{item['id']}_{int(now.timestamp())}"

    conn.execute(
        """
        INSERT INTO requests (
          trace_id, name, username, raw_text, category, priority, sentiment,
          summary, suggested_reply, confidence, needs_review, status, model,
          tokens_in, tokens_out, cost_usd, sla_due_at, created_at, ai_raw
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'new', ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            trace_id, item["from"], item["username"], item["text"],
            result["category"], result["priority"], result["sentiment"],
            result["summary"], result["suggested_reply"], result["confidence"],
            int(result["needs_review"]), model, tokens_in, tokens_out, cost,
            sla_due.isoformat(), now.isoformat(),
            json.dumps({k: result.get(k) for k in ("category", "priority", "sentiment", "confidence")}, ensure_ascii=False),
        ),
    )
    conn.commit()
    return {"tokens_in": tokens_in, "tokens_out": tokens_out, "cost_usd": cost, "sla_due_at": sla_due}


def fmt_money(value: float) -> str:
    if value < 0.01:
        return f"${value:.6f}"
    if value < 1:
        return f"${value:.4f}"
    return f"${value:.2f}"


def print_header(mode: str) -> None:
    print("=" * 78)
    print("  AI REQUEST DESK · локальное демо классификации заявок")
    print("=" * 78)
    print(f"  режим: {mode}")
    print(f"  модель: {MODEL}")
    print(f"  тариф: ${PRICE_IN}/1M вход · ${PRICE_OUT}/1M выход")
    print(f"  SLA: critical 15 мин · high 60 мин · normal 4 ч · low 24 ч")
    print("=" * 78)
    print()


def print_item(idx: int, item: dict, result: dict, saved: dict) -> None:
    ok_cat = result["category"] == item["expected_category"]
    ok_prio = result["priority"] == item["expected_priority"]
    mark = "OK" if ok_cat and ok_prio else "MISS"
    conf = int(round(result["confidence"] * 100))

    print(f"[{idx:02d}] #{item['id']}  {result['category']} / {PRIORITY_LABELS[result['priority']]:<10}  conf {conf:>3}%  SLA {SLA_MINUTES[result['priority']]:>4} мин   {mark}")
    print(f"     клиент: {item['from']} (@{item['username']})")
    print(f"     текст:  {item['text']}")
    print(f"     summary: {result['summary']}")
    if result["suggested_reply"]:
        print(f"     reply:   {result['suggested_reply']}")
    if not (ok_cat and ok_prio):
        print(f"     ожидалось: {item['expected_category']} / {item['expected_priority']}")
    if result["needs_review"]:
        print("     флаг: needs_review")
    print(f"     токены: {saved['tokens_in']} in / {saved['tokens_out']} out · стоимость {fmt_money(saved['cost_usd'])}")
    print("-" * 78)


def print_stats(conn: sqlite3.Connection, results: list[dict], items: list[dict], saved_rows: list[dict]) -> None:
    total = len(items)
    cat_ok = sum(r["category"] == i["expected_category"] for r, i in zip(results, items))
    prio_ok = sum(r["priority"] == i["expected_priority"] for r, i in zip(results, items))
    both_ok = sum(
        r["category"] == i["expected_category"] and r["priority"] == i["expected_priority"]
        for r, i in zip(results, items)
    )

    priority_counts = Counter(r["priority"] for r in results)
    category_counts = Counter(r["category"] for r in results)
    total_cost = sum(s["cost_usd"] for s in saved_rows)
    total_tokens_in = sum(s["tokens_in"] for s in saved_rows)
    total_tokens_out = sum(s["tokens_out"] for s in saved_rows)

    print()
    print("=" * 78)
    print("  ИТОГИ")
    print("=" * 78)
    print(f"  Заявок обработано: {total}")
    print(f"  Категория верна:   {cat_ok}/{total}")
    print(f"  Приоритет верен:   {prio_ok}/{total}")
    print(f"  Оба поля верны:    {both_ok}/{total}")
    print()
    print("  Приоритеты: " + " · ".join(f"{PRIORITY_LABELS[p].lower()} {priority_counts[p]}" for p in ("critical", "high", "normal", "low")))
    print("  Категории:  " + " · ".join(f"{CATEGORY_LABELS[c].lower()} {n}" for c, n in category_counts.most_common()))
    print()
    print(f"  Токены: {total_tokens_in} in / {total_tokens_out} out")
    print(f"  Стоимость пачки: {fmt_money(total_cost)}")
    if total:
        per_1000 = total_cost / total * 1000
        print(f"  Прогноз на 1 000 заявок: {fmt_money(per_1000)}")
        print(f"  Прогноз на 3 000 заявок/мес: {fmt_money(per_1000 * 3)}")
    print()

    rows = conn.execute(
        """
        SELECT category, count(*) AS total,
               sum(CASE WHEN priority IN ('high', 'critical') THEN 1 ELSE 0 END) AS urgent,
               round(avg(confidence), 2) AS avg_conf
        FROM requests
        GROUP BY category
        ORDER BY total DESC, category
        """
    ).fetchall()
    print("  SQL-срез по категориям:")
    print("    " + f"{'категория':<14}{'всего':>6}{'срочных':>9}{'ср. conf':>10}")
    for category, count, urgent, avg_conf in rows:
        print(f"    {CATEGORY_LABELS.get(category, category):<14}{count:>6}{urgent:>9}{avg_conf:>10}")
    print()

    rows = conn.execute(
        """
        SELECT id, priority, category, sla_due_at
        FROM requests
        ORDER BY CASE priority
          WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END
        LIMIT 3
        """
    ).fetchall()
    print("  Первые в очереди менеджера:")
    for ticket_id, priority, category, sla_due_at in rows:
        due = datetime.fromisoformat(sla_due_at).strftime("%H:%M")
        print(f"    #{ticket_id}  {PRIORITY_LABELS[priority]:<10}  {CATEGORY_LABELS[category]:<12}  SLA до {due} UTC")
    print()
    print(f"  SQLite: {DB_PATH.relative_to(ROOT)}")
    print("  Postgres-версия: см. sql/01_schema.sql и n8n/request-desk.workflow.json")
    print("=" * 78)


def main() -> int:
    items = json.loads(REQUESTS_PATH.read_text(encoding="utf-8"))
    system_prompt, examples = load_prompt()
    api_key = os.getenv("OPENROUTER_API_KEY", "").strip()

    mode = "OpenRouter: " + MODEL if api_key else "offline: эвристика (без API-ключа)"
    print_header(mode)

    conn = init_db()
    results = []
    saved_rows = []

    for idx, item in enumerate(items, start=1):
        if api_key:
            try:
                result = ai_classify(item["text"], system_prompt, examples, api_key)
            except (urllib.error.URLError, urllib.error.HTTPError, KeyError, ValueError, json.JSONDecodeError) as exc:
                print(f"  [warn] OpenRouter недоступен ({exc}), fallback на эвристику\n")
                result = heuristic_classify(item["text"])
        else:
            result = heuristic_classify(item["text"])

        saved = save_request(conn, item, result, system_prompt)
        results.append(result)
        saved_rows.append(saved)
        print_item(idx, item, result, saved)

    print_stats(conn, results, items, saved_rows)
    conn.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
