BEGIN;

CREATE SCHEMA IF NOT EXISTS request_desk;

DO $$
BEGIN
  CREATE TYPE request_desk.request_category AS ENUM
    ('sales', 'support', 'billing', 'delivery', 'partnership', 'spam', 'other');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$
BEGIN
  CREATE TYPE request_desk.request_priority AS ENUM
    ('low', 'normal', 'high', 'critical');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$
BEGIN
  CREATE TYPE request_desk.request_status AS ENUM
    ('new', 'in_progress', 'waiting', 'done', 'spam');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$
BEGIN
  CREATE TYPE request_desk.request_sentiment AS ENUM
    ('positive', 'neutral', 'negative');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS request_desk.requests (
  id                  BIGSERIAL PRIMARY KEY,
  trace_id            TEXT NOT NULL UNIQUE,
  source              TEXT NOT NULL DEFAULT 'telegram',

  external_message_id BIGINT,
  chat_id             BIGINT NOT NULL,
  user_id             BIGINT,
  username            TEXT,
  full_name           TEXT,

  raw_text            TEXT NOT NULL,
  category            request_desk.request_category NOT NULL DEFAULT 'other',
  priority            request_desk.request_priority NOT NULL DEFAULT 'normal',
  sentiment           request_desk.request_sentiment NOT NULL DEFAULT 'neutral',
  summary             TEXT,
  suggested_reply     TEXT,
  confidence          NUMERIC(4, 3),
  needs_review        BOOLEAN NOT NULL DEFAULT FALSE,

  status              request_desk.request_status NOT NULL DEFAULT 'new',
  assignee_id         BIGINT,
  assignee_name       TEXT,

  model               TEXT,
  tokens_in           INTEGER,
  tokens_out          INTEGER,
  cost_usd            NUMERIC(12, 6),
  ai_raw              JSONB,

  sla_due_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_at           TIMESTAMPTZ,

  CONSTRAINT confidence_range CHECK (confidence IS NULL OR (confidence >= 0 AND confidence <= 1))
);

COMMENT ON TABLE request_desk.requests IS 'Заявки из Telegram с AI-классификацией и SLA';
COMMENT ON COLUMN request_desk.requests.trace_id IS 'Идемпотентный идентификатор обработки';
COMMENT ON COLUMN request_desk.requests.needs_review IS 'AI не уверен или вернул невалидный ответ';
COMMENT ON COLUMN request_desk.requests.cost_usd IS 'Стоимость вызова LLM в USD';

CREATE INDEX IF NOT EXISTS idx_requests_status_priority
  ON request_desk.requests (status, priority, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_requests_category_created
  ON request_desk.requests (category, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_requests_created
  ON request_desk.requests (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_requests_chat
  ON request_desk.requests (chat_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_requests_sla_open
  ON request_desk.requests (sla_due_at)
  WHERE status IN ('new', 'in_progress', 'waiting');

CREATE INDEX IF NOT EXISTS idx_requests_ai_raw
  ON request_desk.requests USING GIN (ai_raw);

CREATE OR REPLACE FUNCTION request_desk.touch_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_requests_touch ON request_desk.requests;
CREATE TRIGGER trg_requests_touch
BEFORE UPDATE ON request_desk.requests
FOR EACH ROW
EXECUTE FUNCTION request_desk.touch_updated_at();

CREATE OR REPLACE VIEW request_desk.v_daily_stats AS
SELECT
  created_at::date AS day,
  count(*) AS total,
  count(*) FILTER (WHERE status = 'done') AS done,
  count(*) FILTER (WHERE needs_review) AS needs_review,
  count(*) FILTER (WHERE priority IN ('high', 'critical')) AS urgent,
  round(avg(confidence), 3) AS avg_confidence,
  round(sum(cost_usd), 6) AS ai_cost_usd
FROM request_desk.requests
GROUP BY created_at::date
ORDER BY day DESC;

CREATE OR REPLACE VIEW request_desk.v_category_mix AS
SELECT
  category,
  count(*) AS total,
  count(*) FILTER (WHERE priority IN ('high', 'critical')) AS urgent,
  round(avg(confidence), 3) AS avg_confidence,
  round(avg(cost_usd), 6) AS avg_cost_usd
FROM request_desk.requests
GROUP BY category
ORDER BY total DESC;

CREATE OR REPLACE VIEW request_desk.v_sla_risk AS
SELECT
  id,
  category,
  priority,
  status,
  summary,
  sla_due_at,
  now() - sla_due_at AS overdue_by
FROM request_desk.requests
WHERE status IN ('new', 'in_progress', 'waiting')
  AND sla_due_at < now()
ORDER BY sla_due_at;

CREATE OR REPLACE VIEW request_desk.v_resolution AS
SELECT
  date_trunc('week', created_at)::date AS week,
  count(*) FILTER (WHERE closed_at IS NOT NULL) AS closed,
  round(avg(extract(epoch FROM (closed_at - created_at)) / 60.0), 1) AS avg_minutes_to_close,
  round(100.0 * count(*) FILTER (WHERE closed_at IS NOT NULL AND closed_at <= sla_due_at)
        / NULLIF(count(*) FILTER (WHERE closed_at IS NOT NULL), 0), 1) AS sla_compliance_pct
FROM request_desk.requests
GROUP BY 1
ORDER BY week DESC;

COMMIT;
