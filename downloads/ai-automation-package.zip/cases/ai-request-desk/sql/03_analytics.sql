-- Примеры запросов для дашборда / отчёта работодателю.
-- Все запросы используют только схему request_desk.

-- 1. Сводка за последние 7 дней
SELECT
  count(*) AS total,
  count(*) FILTER (WHERE priority = 'critical') AS critical,
  count(*) FILTER (WHERE priority = 'high') AS high,
  count(*) FILTER (WHERE needs_review) AS needs_review,
  round(avg(confidence), 3) AS avg_confidence,
  round(sum(cost_usd), 6) AS ai_cost_usd
FROM request_desk.requests
WHERE created_at >= now() - interval '7 days';

-- 2. Распределение по категориям и приоритетам
SELECT category, priority, count(*) AS total
FROM request_desk.requests
WHERE created_at >= now() - interval '30 days'
GROUP BY category, priority
ORDER BY category, priority;

-- 3. Просроченные SLA: что менеджеру нужно взять в работу прямо сейчас
SELECT id, priority, category, summary, sla_due_at, now() - sla_due_at AS overdue_by
FROM request_desk.requests
WHERE status IN ('new', 'in_progress', 'waiting')
  AND sla_due_at < now()
ORDER BY priority DESC, sla_due_at;

-- 4. Среднее время закрытия и соблюдение SLA по неделям
SELECT * FROM request_desk.v_resolution;

-- 5. Стоимость AI за месяц и прогноз на 1 000 заявок
SELECT
  count(*) AS requests,
  round(sum(cost_usd), 6) AS total_cost_usd,
  round(avg(cost_usd), 6) AS avg_cost_usd,
  round(avg(cost_usd) * 1000, 4) AS cost_per_1000_usd
FROM request_desk.requests
WHERE created_at >= date_trunc('month', now());

-- 6. Качество классификации: где AI чаще ошибается / просит проверку
SELECT
  category,
  count(*) AS total,
  count(*) FILTER (WHERE needs_review) AS needs_review,
  round(100.0 * count(*) FILTER (WHERE needs_review) / count(*), 1) AS review_rate_pct,
  round(avg(confidence), 3) AS avg_confidence
FROM request_desk.requests
GROUP BY category
ORDER BY review_rate_pct DESC;

-- 7. Загрузка менеджеров
SELECT
  coalesce(assignee_name, 'Не назначен') AS assignee,
  count(*) AS total,
  count(*) FILTER (WHERE status IN ('new', 'in_progress', 'waiting')) AS open,
  count(*) FILTER (WHERE status = 'done') AS done
FROM request_desk.requests
GROUP BY coalesce(assignee_name, 'Не назначен')
ORDER BY total DESC;
