INSERT INTO request_desk.requests (
  trace_id, external_message_id, chat_id, user_id, username, full_name,
  raw_text, category, priority, sentiment, summary, suggested_reply,
  confidence, needs_review, status, assignee_id, assignee_name,
  model, tokens_in, tokens_out, cost_usd, sla_due_at, created_at, closed_at, ai_raw
)
VALUES
(
  'seed_001', 501, 100001, 200001, 'ivan_p', 'Иван Петров',
  'Здравствуйте! Вчера оплатил заказ, деньги списались дважды. Заказ 4821. Верните лишнее списание, пожалуйста.',
  'billing', 'high', 'negative',
  'Двойное списание по заказу 4821, клиент просит возврат.',
  'Иван, передали заявку в финансовый отдел. Проверим списание по заказу 4821 и вернёмся с решением в течение часа.',
  0.940, FALSE, 'done', 300001, 'Анна (финансы)',
  'qwen/qwen3.7-flash', 735, 104, 0.000036, now() - interval '20 minutes', now() - interval '2 hours', now() - interval '40 minutes',
  '{"category":"billing","priority":"high","sentiment":"negative","confidence":0.94}'::jsonb
),
(
  'seed_002', 502, 100002, 200002, 'olga_m', 'Ольга Максимова',
  'Срочно! Сайт не открывается, клиенты не могут оформить заказ. Потеряли уже несколько продаж.',
  'support', 'critical', 'negative',
  'Сайт недоступен, клиенты не могут оформлять заказы.',
  'Ольга, приняли как критическую заявку. Инженер уже проверяет доступность сайта, вернёмся с статусом в течение 15 минут.',
  0.970, FALSE, 'in_progress', 300002, 'Дмитрий (поддержка)',
  'qwen/qwen3.7-flash', 741, 112, 0.000037, now() + interval '5 minutes', now() - interval '25 minutes', NULL,
  '{"category":"support","priority":"critical","sentiment":"negative","confidence":0.97}'::jsonb
),
(
  'seed_003', 503, 100003, 200003, 'max_s', 'Максим Соколов',
  'Хочу узнать стоимость корпоративного тарифа на 50 сотрудников. Есть ли скидка при годовой оплате?',
  'sales', 'normal', 'neutral',
  'Запрос цены корпоративного тарифа на 50 сотрудников.',
  'Максим, отправили запрос менеджеру по продажам. Подготовим расчёт на 50 сотрудников и условия годовой оплаты.',
  0.910, FALSE, 'new', NULL, NULL,
  'qwen/qwen3.7-flash', 729, 96, 0.000034, now() + interval '4 hours', now() - interval '15 minutes', NULL,
  '{"category":"sales","priority":"normal","sentiment":"neutral","confidence":0.91}'::jsonb
),
(
  'seed_004', 504, 100004, 200004, 'elena_k', 'Елена Кузнецова',
  'Подскажите, когда придёт доставка? Заказ 5170, обещали сегодня до 18:00, но статус не меняется.',
  'delivery', 'high', 'neutral',
  'Клиент уточняет статус доставки заказа 5170.',
  'Елена, запросили статус у службы доставки по заказу 5170. Сообщим обновление, как только получим ответ.',
  0.880, FALSE, 'waiting', 300003, 'Сергей (логистика)',
  'qwen/qwen3.7-flash', 733, 101, 0.000035, now() + interval '40 minutes', now() - interval '70 minutes', NULL,
  '{"category":"delivery","priority":"high","sentiment":"neutral","confidence":0.88}'::jsonb
),
(
  'seed_005', 505, 100005, 200005, 'partner_x', 'Алексей Орлов',
  'Добрый день! Мы агентство, предлагаем партнёрство по продвижению. Кому можно отправить коммерческое предложение?',
  'partnership', 'low', 'positive',
  'Предложение партнёрства от рекламного агентства.',
  'Алексей, спасибо за интерес. Передали предложение в отдел развития партнёрств, ответим в рабочее время.',
  0.870, FALSE, 'new', NULL, NULL,
  'qwen/qwen3.7-flash', 738, 99, 0.000035, now() + interval '24 hours', now() - interval '45 minutes', NULL,
  '{"category":"partnership","priority":"low","sentiment":"positive","confidence":0.87}'::jsonb
),
(
  'seed_006', 506, 100006, 200006, 'kirill', 'Кирилл Иванов',
  'Не приходит письмо с подтверждением регистрации, проверил спам — пусто. Почта: kirill@example.com',
  'support', 'normal', 'negative',
  'Не приходит письмо подтверждения регистрации.',
  'Кирилл, проверим отправку письма на kirill@example.com. Если оно не дойдёт, активируем аккаунт вручную.',
  0.930, FALSE, 'done', 300002, 'Дмитрий (поддержка)',
  'qwen/qwen3.7-flash', 742, 107, 0.000036, now() - interval '2 hours', now() - interval '4 hours', now() - interval '3 hours',
  '{"category":"support","priority":"normal","sentiment":"negative","confidence":0.93}'::jsonb
),
(
  'seed_007', 507, 100007, 200007, 'spam_bot', NULL,
  'Купите готовую базу клиентов, только сегодня скидка 90%. Пишите в личку.',
  'spam', 'low', 'neutral',
  'Рекламное сообщение о продаже базы клиентов.',
  '',
  0.990, FALSE, 'spam', NULL, NULL,
  'qwen/qwen3.7-flash', 721, 74, 0.000031, now() + interval '24 hours', now() - interval '3 hours', now() - interval '3 hours',
  '{"category":"spam","priority":"low","sentiment":"neutral","confidence":0.99}'::jsonb
),
(
  'seed_008', 508, 100008, 200008, 'maria_l', 'Мария Лебедева',
  'Приложение вылетает при загрузке фото на iPhone. Версия iOS 18.3, приложение последнее. Очень мешает работе.',
  'support', 'high', 'negative',
  'Приложение падает при загрузке фото на iPhone.',
  'Мария, спасибо за детали. Передали разработке, проверим сценарий с загрузкой фото на iOS 18.3 и сообщим о результате.',
  0.900, FALSE, 'in_progress', 300004, 'Павел (разработка)',
  'qwen/qwen3.7-flash', 747, 113, 0.000037, now() + interval '35 minutes', now() - interval '85 minutes', NULL,
  '{"category":"support","priority":"high","sentiment":"negative","confidence":0.90}'::jsonb
),
(
  'seed_009', 509, 100009, 200009, 'nina_v', 'Нина Волкова',
  'Нужен возврат средств за отменённый заказ. Отменила вчера, деньги до сих пор не пришли.',
  'billing', 'high', 'negative',
  'Клиент ждёт возврат за отменённый заказ.',
  'Нина, зафиксировали обращение по возврату. Финансовый отдел проверит платёж и сообщит срок зачисления.',
  0.950, FALSE, 'new', NULL, NULL,
  'qwen/qwen3.7-flash', 734, 102, 0.000035, now() + interval '55 minutes', now() - interval '5 minutes', NULL,
  '{"category":"billing","priority":"high","sentiment":"negative","confidence":0.95}'::jsonb
),
(
  'seed_010', 510, 100010, 200010, 'andrey', 'Андрей Смирнов',
  'Спасибо, всё работает. Отдельное спасибо поддержке за быстрое решение вчера.',
  'other', 'low', 'positive',
  'Клиент благодарит поддержку, проблема решена.',
  'Андрей, спасибо за отзыв! Передали благодарность команде поддержки.',
  0.780, TRUE, 'done', 300002, 'Дмитрий (поддержка)',
  'qwen/qwen3.7-flash', 725, 88, 0.000033, now() - interval '20 hours', now() - interval '5 hours', now() - interval '4 hours',
  '{"category":"other","priority":"low","sentiment":"positive","confidence":0.78}'::jsonb
)
ON CONFLICT (trace_id) DO NOTHING;
