# AI Automation Portfolio — пакет файлов

## Что внутри

- `landing/` — новый интерактивный лендинг (ночная редакционная эстетика).
- `portfolio/` — полное портфолио, PDF, кейсы, SQL, промпты, демо.
- `resume/` — резюме PDF, HTML, Markdown, текст для hh.ru, сопроводительное и стратегия поиска.
- `cases/ai-request-desk/` — n8n-workflow, SQL-схема, аналитика, промпт, демо.
- `n8n-workflows/` — JSON-воркфлоу без секретов и credentials.

## Как открыть

- Лендинг: `landing/index.html`
- Полное портфолио: `portfolio/index.html`
- Резюме: `resume/resume.pdf`
- Текст для hh.ru: `resume/resume-hh.txt`

## Безопасность

В пакет **не включены** `.env`, токены, пароли, credentials, базы данных и бэкапы.
Для запуска n8n-воркфлоу подключите свои credentials в интерфейсе n8n.

## Ссылки

- Live-лендинг: https://dated-cpu.github.io/portfolio/
- GitHub: https://github.com/Dated-cpu
- Telegram: @Danil_Andreeviches
- Email: golovin_da@icloud.com
