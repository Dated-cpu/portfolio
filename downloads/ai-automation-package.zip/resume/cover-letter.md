# Сопроводительное письмо

Здравствуйте!

Меня зовут Данил. Я AI Automation / Full-stack engineer: n8n, Telegram, API, SQL, Python/FastAPI, React.

За 2026 год я собрал 6 проектов end-to-end. Среди них коммерческая платформа **Vlada_BROWS** — Next.js 15, tRPC, Prisma, PostgreSQL, OAuth VK/Яндекс, админ-панель, 361 unit + 65 e2e. И Telegram Mini App **«Трендыч»** — AI-видео 9:16, оплата Telegram Stars, очередь генерации, 23 REST endpoint и 9 таблиц. Ещё один кейс — **AI Request Desk**: n8n + LLM классифицируют заявки, PostgreSQL хранит SLA и стоимость, менеджер получает карточку с кнопками.

Мне интересны задачи, где нужно соединить процесс, данные и AI, а не просто «прикрутить чат-бота». Я умею разбирать процесс, проектировать схему данных и API, считать стоимость AI, обрабатывать ошибки и доводить до продакшена.

Портфолио: https://dated-cpu.github.io/portfolio/  
GitHub: https://github.com/Dated-cpu  
Telegram: @Danil_Andreeviches  
Email: golovin_da@icloud.com

Буду рад обсудить, какую рутину можно убрать у вашей команды в первую очередь.
