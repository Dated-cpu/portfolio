# Данил Андреевич

**AI Automation / Full-stack Engineer**

Удалённо · Telegram: @Danil_Andreeviches · Email: golovin_da@icloud.com  
Портфолио: https://dated-cpu.github.io/portfolio/ · GitHub: https://github.com/Dated-cpu

## О себе

AI Automation / Full-stack engineer. Собираю end-to-end системы: n8n, Telegram, API, SQL и LLM. За 2026 год сделал 6 проектов, включая коммерческую платформу **Vlada_BROWS** (Next.js, tRPC, Prisma, PostgreSQL, OAuth, 361 unit + 65 e2e) и Telegram Mini App **«Трендыч»** с оплатой Stars и AI-видео. Умею разбирать процесс, проектировать данные, считать стоимость AI и доводить до продакшена. Ищу роль AI Automation Engineer, n8n-разработчика, Backend/Full-stack (Python/React) или интегратора.

## Навыки

- **Автоматизация:** n8n (webhook, Switch, Code, HTTP Request, Postgres, Wait, callbacks), Telegram Bot API, Telegram Mini Apps, Telegram Stars.
- **Backend:** Python, FastAPI, Pydantic, SQLAlchemy 2 (async), Alembic, JWT, OAuth, REST, webhooks, background tasks, file uploads.
- **Базы данных:** PostgreSQL, SQLite, SQL, Prisma, enum, indexes, views, transactions, prepared statements, идемпотентные миграции.
- **Frontend:** React 19, Next.js 15, TypeScript, Vite, Tailwind, tRPC, React Query, Framer Motion.
- **AI/LLM:** OpenRouter, qwen, Gemini, prompt engineering, JSON schema, multimodal, image generation, fallback, cost control.
- **Инфраструктура:** Docker, Docker Compose, Caddy, HTTPS, VPS, reverse proxy, backups, secrets, GitHub Actions, Dependabot.

## Проекты

### Vlada_BROWS — коммерческая платформа для студии бровей и ресниц · 2026
Next.js 15, tRPC, Prisma, PostgreSQL, OAuth VK/Яндекс, RBAC, админ-панель.
- 20 моделей Prisma, 361 unit + 65 e2e, CSP/CSRF/rate limit, audit log.
- Лендинг, онлайн-запись, кабинеты, услуги, отзывы, медиа.
- Live: https://beauty-master-platform.vercel.app (код приватный).

### Трендыч — Telegram Mini App для AI-видео · 2026
React 19, FastAPI, SQLAlchemy, PostgreSQL, Telegram Stars, n8n, OpenRouter.
- 23 REST endpoint, 9 таблиц, 6 шаблонов, live-платежи, очередь, история, аналитика.
- Live: https://hansslanda.ru · Бот: @Trendych_bot

### AI Request Desk — автоматизация заявок из Telegram · 2026
n8n, Telegram, OpenRouter, PostgreSQL, SQL.
- 26 нод, 7 категорий, 4 приоритета, 12/12 на тестовом наборе, ~$0.036 за 1 000 заявок.
- Строгий JSON + fallback, SLA, кнопки менеджера и клиента, SQL-вьюхи.
- Демо: @zayavka_assist_bot

### AI-ассистент — мультимодальный Telegram-бот · 2026
n8n, OpenRouter, qwen, Gemini.
- 25 нод, 4 режима (текст, голос, фото, /image), 3 модели, fallback-ответы.
- Бот: @danil_agent_ai_bot

### BookFlow AI — scheduling SaaS foundation · 2026
FastAPI, async SQLAlchemy, PostgreSQL, Clean Architecture, JWT, Alembic, Docker.
- Domain/application/infrastructure/presentation, repository pattern, тесты.
- GitHub: https://github.com/Dated-cpu/BookFlow

### BarberPro — booking SaaS для барбершопа · 2026
Next.js 15, tRPC, Prisma, PostgreSQL, Redis/BullMQ, R3F.
- Слоты, расписание, кабинеты, outbox, очереди уведомлений.
- Live: https://web-khaki-beta-29.vercel.app · GitHub: https://github.com/Dated-cpu/barberpro

## Опыт

**Независимая проектная разработка** · 2026 — н.в.
- 6 проектов end-to-end: от схемы данных и API до интерфейса, платежей, деплоя и аналитики.
- Коммерческий проект Vlada_BROWS: production-платформа с OAuth, RBAC, админ-панелью и тестами.
- Автоматизации на n8n: Telegram, OpenRouter, PostgreSQL, SLA, стоимость AI.
- Публичные репозитории и живое портфолио: https://github.com/Dated-cpu

## Образование и обучение

- Самообразование и практика: n8n, FastAPI, PostgreSQL, React, LLM-интеграции.
- Постоянно учусь через собственные продукты, документацию и разбор архитектуры.

## Дополнительно

- Продуктовое мышление, автономность, документация, доведение до продакшена.
- Внимание к безопасности (OAuth, HMAC, CSRF, CSP, rate limit) и стоимости AI.
- Формат: удалённо. Открыт к full-time, проектам и контракту.
