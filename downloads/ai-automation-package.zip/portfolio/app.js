(() => {
  const printButtons = document.querySelectorAll('[data-print]');
  printButtons.forEach((button) => {
    button.addEventListener('click', () => {
      window.print();
    });
  });

  const year = new Date().getFullYear();
  const footer = document.querySelector('.site-footer .footer-inner span');
  if (footer) {
    footer.textContent = `Данил Андреевич · ${year}`;
  }
})();
